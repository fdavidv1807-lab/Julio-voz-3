# Voz de Julio (Kokoro): APK de prueba (proyecto independiente)

App Android mínima cuyo único fin es **generar y reproducir una voz neuronal real** a partir de cualquier texto, para decidir si la voz te gusta. No toca ni depende de la app principal de Julio.

## Qué hace
Escribes texto → generas → escuchas → detienes. Eliges entre `em_alex` (masculina, español) y `ef_dora` (femenina, solo para comparar), ajustas velocidad y volumen, y tienes las 5 frases de prueba. Muestra tiempo de generación y memoria aproximada.

## Motor y modelos
- Motor: **sherpa-onnx** (Apache-2.0), AAR oficial de `github.com/k2-fsa/sherpa-onnx`.
- Modelo: **Kokoro-82M multilingüe** (`kokoro-multi-lang-v1_0`) desde los releases oficiales de sherpa-onnx (`tts-models`). Solo hay una voz masculina en español en este modelo.
- Todo se descarga **durante la compilación en GitHub**, no en tu teléfono, y los modelos van dentro del APK: la app funciona **sin internet**.

## Seguridad y permisos
- **Permisos que pide: ninguno.** El manifiesto no declara `INTERNET`, así que la app no puede enviar ni recibir datos por red. No usa micrófono, contactos, archivos ni ubicación.
- Sin publicidad, rastreo ni código de terceros aparte del motor sherpa-onnx.
- El flujo de compilación imprime el SHA-256 de cada archivo descargado para que lo puedas revisar.
- El APK sale firmado con la clave de depuración: sirve para pruebas, no para publicarlo.
- Licencias: el código de este proyecto es MIT. **Cada voz tiene su propia licencia**: revisa la ficha de cada modelo antes de distribuirla en Julio.

## Cómo obtener el APK desde el teléfono (sin PC)
1. En github.com crea un repositorio **nuevo** (por ejemplo `julio-voz-kokoro-apk`), privado si quieres.
2. `Add file → Create new file`. En el nombre escribe exactamente `.github/workflows/build.yml` y pega todo el contenido de `build-kokoro-todo-en-uno.yml` (de este ZIP). Guarda con `Commit changes`.
3. Pestaña **Actions** → `Compilar APK` → `Run workflow`. Tarda unos minutos.
4. Al terminar, entra en esa ejecución y descarga el artefacto **julio-voz-kokoro-apk** (un ZIP con el `.apk`).
5. Descomprime, abre el `.apk` e instala (Android pedirá permitir instalar desde tu navegador o gestor de archivos; desactívalo después).

`build-kokoro-todo-en-uno.yml` genera todos los archivos del proyecto al compilar. Los fuentes legibles están en este mismo ZIP (`app/`, `settings.gradle.kts`, etc.) por si prefieres subirlos tal cual junto con `build.yml`.

## Tamaño aproximado
El modelo Kokoro es grande: el APK puede pesar unos 300–400 MB. Se ve al compilar (`du -sh`).

## Estado honesto
- **Nunca se compiló ni se ejecutó** (el entorno donde se escribió no tiene internet). Es normal que la primera compilación falle y haya que corregir: si pasa, copia el error de la pestaña Actions.
- Puntos más probables de fallo: la URL del AAR (cambia `SHERPA_VERSION` en el flujo), el parámetro `lang` de Kokoro según la versión de sherpa-onnx, o los nombres de archivos dentro del modelo.
- Ninguna voz ha sido escuchada todavía.
- Fuera de alcance por ahora: integrar con Julio.
