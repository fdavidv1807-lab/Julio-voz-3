package com.julio.voz

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Prueba de voz neuronal local (Kokoro vía sherpa-onnx). Sin permisos, sin internet.
 * El modelo vive en assets/kokoro/{model.onnx, voices.bin, tokens.txt, espeak-ng-data/}.
 */
class MainActivity : Activity() {

    // Voces en español del modelo kokoro-multi-lang-v1_0 (identificadores de hablante).
    private val sidByVoice = linkedMapOf("em_alex (masculina)" to 29, "ef_dora (femenina)" to 28)
    private val voices = sidByVoice.keys.toList()
    private val phrases = listOf(
        "Buenos días. ¿Cómo puedo ayudarte hoy?",
        "He revisado tus actividades pendientes. Tienes una clase programada para las siete de la mañana.",
        "Entendido. He guardado la información correctamente.",
        "Permíteme explicarte los detalles y las opciones disponibles.",
        "Tu sesión de estudio ha terminado. Es momento de tomar un descanso."
    )

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val generation = AtomicInteger(0)
    private var tts: OfflineTts? = null
    private var track: AudioTrack? = null
    private var speed = 1.0f
    private var volume = 1.0f

    private lateinit var input: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var statusView: TextView
    private lateinit var generateBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { System.loadLibrary("sherpa-onnx-jni") } catch (_: Throwable) { }
        buildUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        generation.incrementAndGet()
        stopAudio()
        worker.execute { tts?.free(); tts = null }
        worker.shutdown()
    }

    // ---------- Interfaz ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, dp(12), 0, dp(2)) }
        fun add(v: android.view.View) = col.addView(
            v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        add(TextView(this).apply { text = "Voz de Julio (Kokoro)"; textSize = 22f })
        add(TextView(this).apply { text = "Voz neuronal local. Sin internet ni permisos." })

        add(label("Voz"))
        voiceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
        }
        add(voiceSpinner)

        add(label("Texto"))
        input = EditText(this).apply {
            setText(phrases[0])
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        add(input)

        add(label("Frases de prueba"))
        phrases.forEachIndexed { i, p ->
            add(Button(this).apply {
                text = "${i + 1}. $p"
                isAllCaps = false
                setOnClickListener { input.setText(p) }
            })
        }

        val speedLabel = label("Velocidad: 1.00x")
        add(speedLabel)
        add(SeekBar(this).apply {
            max = 12; progress = 6 // 0.70x a 1.30x
            setOnSeekBarChangeListener(listener { p ->
                speed = 0.7f + p * 0.05f
                speedLabel.text = "Velocidad: %.2fx (se aplica al generar)".format(speed)
            })
        })

        val volLabel = label("Volumen: 100%")
        add(volLabel)
        add(SeekBar(this).apply {
            max = 20; progress = 20
            setOnSeekBarChangeListener(listener { p ->
                volume = p / 20f
                volLabel.text = "Volumen: ${p * 5}%"
                track?.setVolume(volume)
            })
        })

        generateBtn = Button(this).apply {
            text = "Generar y reproducir"
            setOnClickListener { speak() }
        }
        add(generateBtn)
        add(Button(this).apply {
            text = "Detener"
            setOnClickListener {
                generation.incrementAndGet()
                stopAudio()
                setStatus("Detenido.")
            }
        })

        statusView = TextView(this).apply { setPadding(0, dp(12), 0, 0); text = "Listo." }
        add(statusView)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun listener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun setStatus(msg: String) { ui.post { statusView.text = msg } }

    // ---------- Voz ----------
    private fun speak() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val voice = voiceSpinner.selectedItem as String
        val myGen = generation.incrementAndGet()
        stopAudio()
        val currentSpeed = speed
        val sid = sidByVoice[voice] ?: 29

        worker.execute {
            try {
                if (tts == null) {
                    setStatus("Cargando el modelo Kokoro (la primera vez tarda)…")
                    loadModel()
                }
                if (generation.get() != myGen) return@execute
                setStatus("Generando…")
                val t0 = SystemClock.elapsedRealtime()
                val audio = tts!!.generate(text, sid, currentSpeed)
                val ms = SystemClock.elapsedRealtime() - t0
                if (generation.get() != myGen) return@execute

                val secs = audio.samples.size.toFloat() / audio.sampleRate
                val mem = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024
                setStatus(
                    "Generado en %.2f s · audio %.1f s · %.2fx tiempo real · memoria ~%d MB"
                        .format(ms / 1000f, secs, ms / 1000f / secs, mem)
                )
                play(audio.samples, audio.sampleRate)
                ui.postDelayed({
                    if (generation.get() == myGen) statusView.append("\nReproducción terminada.")
                }, (secs * 1000).toLong() + 300)
            } catch (t: Throwable) {
                setStatus("Error: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    private fun loadModel() {
        tts?.free(); tts = null
        // espeak-ng necesita rutas reales: copiamos sus datos una vez al almacenamiento privado de la app.
        val espeakDir = File(filesDir, "kokoro/espeak-ng-data")
        if (!File(espeakDir, ".ok").exists()) {
            copyAssetDir("kokoro/espeak-ng-data", espeakDir)
            File(espeakDir, ".ok").writeText("ok")
        }
        val kokoro = OfflineTtsKokoroModelConfig(
            model = "kokoro/model.onnx",
            voices = "kokoro/voices.bin",
            tokens = "kokoro/tokens.txt",
            dataDir = espeakDir.absolutePath,
            lang = "es"
        )
        val modelConfig = OfflineTtsModelConfig(kokoro = kokoro, numThreads = 2, debug = false, provider = "cpu")
        val config = OfflineTtsConfig(model = modelConfig)
        tts = OfflineTts(assetManager = assets, config = config)
    }

    private fun copyAssetDir(assetPath: String, dest: File) {
        val children = assets.list(assetPath)
        if (children.isNullOrEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(assetPath).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (c in children) copyAssetDir("$assetPath/$c", File(dest, c))
        }
    }

    private fun play(samples: FloatArray, sampleRate: Int) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(samples.size * 4)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
        t.setVolume(volume)
        synchronized(this) { track = t }
        t.play()
    }

    private fun stopAudio() {
        synchronized(this) {
            track?.let {
                try { it.stop() } catch (_: Exception) { }
                it.release()
            }
            track = null
        }
    }
}
