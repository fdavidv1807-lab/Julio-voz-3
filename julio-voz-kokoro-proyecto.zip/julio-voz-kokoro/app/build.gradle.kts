plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.julio.voz"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.julio.voz.kokoro"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Los modelos van sin comprimir dentro del APK.
    androidResources { noCompress += listOf("onnx", "txt", "bin") }
}

dependencies {
    // Motor oficial sherpa-onnx (AAR descargado por el flujo de GitHub Actions).
    implementation(files("libs/sherpa-onnx.aar"))
}
